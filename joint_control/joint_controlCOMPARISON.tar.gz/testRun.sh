#!/bin/bash

clear
declare -A robot
robot["Finn"]="python angle_interpolationFINN.py"
robot["Ditti"]="python angle_interpolationDITT.py"

echo "Test commencing: starting Simspark, 7 seconds to get into position"
konsole -e "simspark"
sleep 7
echo "Starting Agents"
cmd='gnome-terminal '
i=0
for robot_name in ${!robot[@]}; do
  cmd+='--tab -t "'${robot_name}'" -e "'${robot[${robot_name}]}'" '
done
echo $cmd
eval $cmd
echo "test running"
exit 0
